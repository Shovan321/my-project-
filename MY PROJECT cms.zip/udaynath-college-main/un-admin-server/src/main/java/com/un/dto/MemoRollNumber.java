package com.un.dto;

import lombok.Data;

@Data
public class MemoRollNumber {
	boolean studentPresent;
	String rollMumber;
}
