package com.un.dto;

import java.util.List;

import lombok.Data;

@Data
public class MemoReportDTO {
	List<MemoDTO> memoModels;
}
