package com.un.dto;

import lombok.Data;

@Data
public class RollNumberForSeatArrangement {
	private String prefix;
	private Integer rollNumber;
	private boolean present;
}
