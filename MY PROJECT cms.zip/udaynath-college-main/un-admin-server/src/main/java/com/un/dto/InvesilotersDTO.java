package com.un.dto;

import lombok.Data;

@Data
public class InvesilotersDTO {
	String name;
	String department;
}
