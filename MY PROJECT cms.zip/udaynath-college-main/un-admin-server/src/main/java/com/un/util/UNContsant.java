package com.un.util;

public class UNContsant {
	public static String ROOM_ARRANGEMENT_HEADER = "U. N. (AUTO) COLLEGE OF SC. & TECH., ADASPUR, CUTTACK";
	public static String ROOM_ARRANGEMENT_HEADER_2 = "ROOM ARRANGEMENT";
	public static String DUTY_LIST = "DUTY LIST";
}
