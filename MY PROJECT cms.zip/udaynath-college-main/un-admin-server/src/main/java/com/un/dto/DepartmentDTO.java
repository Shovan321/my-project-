package com.un.dto;

import lombok.Data;

@Data
public class DepartmentDTO {
	public Long id;
	public String departmentName;
	public String departmentCode;
	public int deptId;
}
