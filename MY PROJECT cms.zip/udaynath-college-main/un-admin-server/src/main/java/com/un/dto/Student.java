package com.un.dto;

import lombok.Data;

@Data
public class Student {
	private String roolNumber;
	private String name;
}
