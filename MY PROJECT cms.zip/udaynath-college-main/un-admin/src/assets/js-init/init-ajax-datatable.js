$(document).ready(function() {
    $(document).ready(function() {
        $('#ajax-datatable').DataTable( {
            "ajax": "assets/vendor/data-tables/data/arrays.txt"
        } );
    } );
} );