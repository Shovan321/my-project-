export const environment = {
  production: true,
  api_url: 'http://localhost/un-admin-server-v1/api/'
};
