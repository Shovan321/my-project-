export class StudentResponseDTO {
    studentsList: any;
    studentNameList: any;
}