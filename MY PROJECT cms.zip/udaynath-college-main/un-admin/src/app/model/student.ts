export class Student{
    roolNumber:string;
    name:string;
}