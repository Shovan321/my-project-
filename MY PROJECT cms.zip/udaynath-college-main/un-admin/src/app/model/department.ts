export class Department {
    id: string;
    departmentName: string;
    departmentCode: string;
    checked:boolean;
}